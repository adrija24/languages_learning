from setuptools import setup
setup(name="packageari",
version="0.1",
description="This is Ari's package",
long_discription="This is a very very long description",
author="Aritra Roy",
email="aritraroy24@gmail.com",
packages=['packageari'],
install_requires=[])