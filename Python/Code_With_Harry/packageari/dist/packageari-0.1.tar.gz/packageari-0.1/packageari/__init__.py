def achhafunc(number):
    print("This is a function")
    return number
